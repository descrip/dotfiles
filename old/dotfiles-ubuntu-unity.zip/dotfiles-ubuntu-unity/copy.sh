#!/bin/bash

# A small script to copy all my dotfiles to the repo.

mkdir -p ./nvim/
cp ~/.config/nvim/init.vim nvim/
cp ~/.config/nvim/ftplugin/ nvim/ -r
cp ~/.config/nvim/templates/ nvim/ -r
cp ~/.config/nvim/plugged/vim-monokai/colors/monokai.vim . -r
cp /etc/default/grub .
cp ~/.latexmkrc .
