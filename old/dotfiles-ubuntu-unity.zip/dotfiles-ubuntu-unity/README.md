# dotfiles

Configurations that I use on my Linux machines.

I've stopped using Arch. If you're looking for my older spectrwm configs (no idea why, it's butt-ugly), checkout the `arch-spectrwm` branch on this repo.

I've since moved to a simple pure Ubuntu installation. Didn't even bother to change the Vim colorscheme.
