# dotfiles

Dotfiles used in my Arch Linux Acer C720 Chromebook, [spectrwm](https://github.com/conformal/spectrwm) with [urxvt](http://software.schmorp.de/pkg/rxvt-unicode.html). The font used in everything is [terminus](http://files.ax86.net/terminus-ttf/).

A slightly modified version of spectrwm is used, where the border is removed when a window is put in fullscreen. You can find it [here](https://github.com/descrip/spectrwm).

There is now a lock screen! It's a slightly modified version of i3lock, and you can find it [here](https://github.com/descrip/i3lock).

## Clean:

![clean](screenshots/clean.png)

## Dirty:

![dirty](screenshots/dirty.png)
